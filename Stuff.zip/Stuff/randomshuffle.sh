#!/bin/bash
### BEGIN INIT INFO
# Provides:          randomshuffle
# Required-Start:    
# Required-Stop:     
# Default-Start:     
# Default-Stop:      
# Short-Description: 
# Description:       
### END INIT INFO
if ( [ -z "$(pgrep mopidy)" ]  ||  mpc | head -1 |  grep -q '^volume' )
    then
    if [ -z "$(pgrep mopidy)" ]
    then
	echo "Starting mopidy"
    	sudo mopidy&
    	sleep 1m
    fi
	if [ $(mpc playlist | wc -l) -eq 0  ]
    then
mpc load "AMS Default"
        sleep 5s
    	RANGE=25
    	number=$RANDOM
    	let "number %= $RANGE"
    	count=1
    	mpc random on
    	while [ "$count" -le "$number" ]      # Generate 10 ($MAXCOUNT) random integers.
    	do
    	  mpc shuffle
    	  sleep 1s
    	  let "count += 1"  # Increment count.
    	done
    fi
	mpc volume 75
	mpc play
else
    echo "mopidy running"
fi
