<?php
	error_reporting(E_ALL | E_WARNING | E_NOTICE);
	ini_set('display_errors', TRUE);

	include("config.php");
	session_start();

	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$user = $_POST['user'];
		$pass = $_POST['pwd'];

		$request = "SELECT id FROM Passwords WHERE user='".$user."' and pass='".$pass."'";
		$result = $db->query($request);

		if ($result->num_rows > 0)
		{
			$_SESSION['loggedIn'] = true;
			header("Location: /admin");
			exit();
		}
		else
		{
			header("Location: /login");
		}
	}
?>
