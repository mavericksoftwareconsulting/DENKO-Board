<?php
	session_start();

	if (!isset($_SESSION['loggedIn']))
	{
		header("Location: /login");
		exit();
	}

	$startTime = $_POST["start"];
	$endTime = $_POST["end"];

	exec("/root/startLater ".$startTime);
	sleep(2);
	exec("/root/killLater ".$endTime);
?>
